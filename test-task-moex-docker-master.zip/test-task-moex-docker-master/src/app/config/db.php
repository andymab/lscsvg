<?php

return [
    'host' => 'localhost',
    'dbname' => 'moex_parce',
    'user' => 'root',
    'password' => 'root',
];